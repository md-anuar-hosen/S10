# Review Checklist v1

For each PR (including PR-S10), reviewers check:

- [ ] Names reveal intent and each function stays at a single level of abstraction.
- [ ] Dependencies are injected or created in a clear place; no hidden singletons/globals in core logic.
- [ ] Error shape follows `/docs/errors/ERROR_RULES.md` (fields: `status`, `code`, `hint`, `correlationId`).
- [ ] Retries are only used for idempotent operations; POST-create uses `Idempotency-Key` when applicable.
- [ ] Side-effects (I/O, DB, network) are at the edges; core logic remains as pure as practical.
- [ ] No secrets or sensitive data are logged; `correlationId` is propagated for tracing.
- [ ] Tests (unit and, where relevant, contract/API) are updated for all changed lines.
- [ ] CI is green (formatter, linter, tests, type checks if configured) before merge.
- [ ] AI-assisted changes, if any, are documented in `/docs/ai/AI_Use_Log.md`.
