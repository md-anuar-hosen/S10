# ERROR_RULES

This file documents the error-handling rules we apply in the S10/S11 booking demo
(Flask-based API in this repository: https://github.com/md-anuar-hosen/S10).

## ERR-01 – API Error Shape

All public errors follow a problem+json-like schema:

- `status` – HTTP status code (integer)
- `code` – stable, machine-readable error code (string), e.g. `BOOKING_INVALID_EMAIL`
- `hint` – short human-readable hint to help the client/user
- `correlationId` – UUID used to correlate logs and responses

Example error body:

```json
{
  "status": 400,
  "code": "BOOKING_INVALID_EMAIL",
  "hint": "Valid email address is required.",
  "correlationId": "c661a9a0-..."
}
```

## ERR-02 – Domain Errors

- Domain-level issues (e.g. invalid booking input, invalid state transitions)
  are represented as typed `ApiError` exceptions rather than plain strings.
- Mapping from domain errors to HTTP responses happens at the API edge
  via the Flask error handler in `app/errors.py`.

## ERR-03 – Infra / Vendor Errors

- Unexpected infrastructure errors (DB, network, etc.) are caught by the generic
  exception handler.
- Clients receive a generic 500 error:

  - `status`: 500
  - `code`: `INTERNAL_ERROR`
  - `hint`: "Unexpected error occurred"
  - `correlationId`: value attached in `before_request`

- Stack traces are **not** returned to clients; they would be logged server-side
  together with the `correlationId` for debugging.

## ERR-04 – Retry & Idempotency

- Only idempotent operations are safe to retry. In this demo:

  - `POST /v1/bookings` is made idempotent via the `Idempotency-Key` header.
  - First call with a new `Idempotency-Key` → 201 Created.
  - Repeated call with the same key (and same logical request) → 200 OK
    with the same booking `id`.

- Clients are expected to implement exponential backoff + jitter when retrying
  requests that failed due to transient issues.

## ERR-05 – Logging

- Each error is associated with a `correlationId`.
- In a real deployment, we would log the following:

  - `correlationId`
  - HTTP method + path
  - key identifiers (e.g. `bookingId`)
  - error `code` and stack trace (for internal logs only)

- Secrets and PII must **never** be logged. In this demo we keep the example
  simple and focus on demonstrating the pattern.
