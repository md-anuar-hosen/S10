# AI Use Log

This file documents where and how AI assistance was used for S10/S11 in
the repository https://github.com/md-anuar-hosen/S10.

## 2025-11-21 – S10 Refactor & Implementation Planning

- **Context:** Designing the `CreateBooking` and `CancelBooking` flows, error model,
  and tests for the S10 assignment.
- **Prompt summary:** Used AI to propose structure for Flask app, error rules,
  and idempotent POST-create behavior. No real customer data or secrets were included.
- **Kept:**
  - Overall design of `create_booking` and `cancel_booking` endpoints.
  - Use of `ApiError` and a problem+json-like error shape.
  - Suggestion to use `Idempotency-Key` for POST `/v1/bookings`.
  - Example unit tests using `pytest` and Flask's test client.
- **Rejected:**
  - Any suggestions involving persistent databases or complex auth flows,
    as they were out of scope for this assignment.
- **Verification:**
  - Verified endpoints manually with the Flask test client.
  - All unit tests in `tests/` pass locally and in CI.
- **Reviewer:** @bahgat (PR #S10-REF)

## 2025-11-21 – S11 Mini Test Plan & Sample Cases

- **Context:** Planning ECP/BVA classes and sample test cases for S1 (CreateBooking)
  and S2 (CancelBooking).
- **Prompt summary:** Used AI to help enumerate equivalence classes, boundaries,
  and example test cases. No production data, logs, or secrets were shared.
- **Kept:**
  - Structure of `/S11/MiniTestPlan.md` and `/S11/SampleCases.md`.
  - Example boundaries for `qty`-like fields, dates, and booking states.
- **Rejected:**
  - Any test ideas that did not match our actual API shape or error codes.
- **Verification:**
  - Cross-checked test cases against the implemented endpoints and
    `/docs/errors/ERROR_RULES.md`; adjusted names and codes to match.
