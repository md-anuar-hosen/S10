# S10 / S11 – Booking Demo (Flask)

This repository contains a small Flask-based booking API used to complete the
S10 and S11 assignments (Implementation Essentials + Mini Test Plan).

Repo URL (to submit in itslearning): https://github.com/md-anuar-hosen/S10

Main components:

- `app/booking_app.py` – Flask app with:
  - `POST /v1/bookings` (S1 – CreateBooking, idempotent with Idempotency-Key)
  - `POST /v1/bookings/<id>/cancel` (S2 – CancelBooking)
- `app/errors.py` – `ApiError` + central error handlers
- `app/storage.py` – in-memory `BookingStore`
- `tests/` – pytest tests for S1 and S2
- `docs/errors/ERROR_RULES.md` – error handling rules
- `docs/review/Review_Checklist_v1.md` – review checklist
- `docs/ai/AI_Use_Log.md` – AI usage log
- `S10/` – S10 README + DIFF
- `S11/` – S11 Mini Test Plan + Sample Cases

## Running Locally

```bash
pip install -r requirements.txt
pytest
```

To run the Flask app:

```bash
export FLASK_APP=app.booking_app:create_app
flask run
```
