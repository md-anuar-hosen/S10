import uuid
from flask import Flask, request, jsonify

from .storage import BookingStore
from .errors import ApiError, register_error_handlers


def create_app():
    app = Flask(__name__)
    store = BookingStore()

    register_error_handlers(app)

    @app.before_request
    def attach_correlation_id():
        # Use incoming header if present, otherwise generate new UUID.
        cid = request.headers.get("X-Correlation-Id") or str(uuid.uuid4())
        # Attach to request so error handlers can read it.
        request.correlation_id = cid

    @app.route("/v1/bookings", methods=["POST"])
    def create_booking():
        """S1 – CreateBooking.

        Validates input and creates a booking. Implements idempotency via Idempotency-Key header.
        """
        payload = request.get_json(silent=True) or {}

        name = (payload.get("name") or "").strip()
        email = (payload.get("email") or "").strip()
        date = (payload.get("date") or "").strip()
        idem_key = request.headers.get("Idempotency-Key")
        correlation_id = request.correlation_id

        # Idempotency: if same key used again, return existing booking with 200.
        if idem_key:
            existing = store.get_by_idempotency_key(idem_key)
            if existing is not None:
                body = {**existing, "correlationId": correlation_id}
                return jsonify(body), 200

        # Validation
        if not name:
            raise ApiError(
                status=400,
                code="BOOKING_INVALID_NAME",
                hint="Name is required.",
                correlation_id=correlation_id,
            )
        if "@" not in email:
            raise ApiError(
                status=400,
                code="BOOKING_INVALID_EMAIL",
                hint="Valid email address is required.",
                correlation_id=correlation_id,
            )
        if not date:
            # For simplicity we do not do full date parsing here.
            raise ApiError(
                status=400,
                code="BOOKING_INVALID_DATE",
                hint="Date is required.",
                correlation_id=correlation_id,
            )

        booking_id = str(uuid.uuid4())
        booking = {
            "id": booking_id,
            "name": name,
            "email": email,
            "date": date,
            "status": "CONFIRMED",
        }

        store.save(booking, idem_key=idem_key)

        body = {**booking, "correlationId": correlation_id}
        return jsonify(body), 201

    @app.route("/v1/bookings/<booking_id>/cancel", methods=["POST"])
    def cancel_booking(booking_id):
        """S2 – CancelBooking.

        Cancels an existing booking if possible.
        """
        correlation_id = request.correlation_id
        booking = store.get(booking_id)

        if booking is None:
            raise ApiError(
                status=404,
                code="BOOKING_NOT_FOUND",
                hint="Booking not found.",
                correlation_id=correlation_id,
            )

        if booking.get("status") == "CANCELLED":
            raise ApiError(
                status=409,
                code="BOOKING_ALREADY_CANCELLED",
                hint="Booking has already been cancelled.",
                correlation_id=correlation_id,
            )

        booking["status"] = "CANCELLED"
        store.save(booking)

        body = {**booking, "correlationId": correlation_id}
        return jsonify(body), 200

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(debug=True)
