class BookingStore:
    """In-memory store used only for this assignment/demo."""
    def __init__(self):
        self._bookings = {}
        self._idempotency = {}

    def save(self, booking, idem_key=None):
        booking_id = booking["id"]
        self._bookings[booking_id] = booking
        if idem_key:
            self._idempotency[idem_key] = booking_id

    def get(self, booking_id):
        return self._bookings.get(booking_id)

    def get_by_idempotency_key(self, idem_key):
        booking_id = self._idempotency.get(idem_key)
        if not booking_id:
            return None
        return self._bookings.get(booking_id)
