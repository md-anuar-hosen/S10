from dataclasses import dataclass
from flask import jsonify, request

@dataclass
class ApiError(Exception):
    status: int
    code: str
    hint: str
    correlation_id: str | None = None


def register_error_handlers(app):
    @app.errorhandler(ApiError)
    def handle_api_error(err: ApiError):
        body = {
            "status": err.status,
            "code": err.code,
            "hint": err.hint,
            "correlationId": err.correlation_id,
        }
        return jsonify(body), err.status

    @app.errorhandler(Exception)
    def handle_unexpected(err: Exception):
        # In a real app, this would log the stack trace + correlationId.
        correlation_id = getattr(request, "correlation_id", None)
        body = {
            "status": 500,
            "code": "INTERNAL_ERROR",
            "hint": "Unexpected error occurred",
            "correlationId": correlation_id,
        }
        return jsonify(body), 500
