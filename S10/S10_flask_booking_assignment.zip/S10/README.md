# S10 – Refactor, Error Rules, Idempotency, Review Checklist

**Team:** Bahgat, Ahmed · Hosen, Md  
**Repo:** https://github.com/md-anuar-hosen/S10

S10 focuses on hardening and refactoring a small Flask-based booking API with:

- A clear error model (problem+json style)
- Idempotent POST-create behavior for booking creation
- Tests that pin current behavior
- A lightweight, practical review checklist
- Transparent AI usage logging

## Target for Refactor

- **Component:** `create_booking` (S1 – CreateBooking) and related helpers in `app/booking_app.py`.
- **Reason:**
  - Central business flow for the demo.
  - Touches validation, idempotency, and error handling.
  - Good candidate to showcase micro-tests and safe refactoring.

## Evidence (Links)

> Replace placeholders like `<PR-LINK>` and `<CI-LINK>` with real URLs once you
> have created the PR and run CI.

- **Refactor PR (PR-S10):** `<PR-LINK>`
- **Diff + peer comments:** `/S10/refactor/DIFF.md`
- **Refactored code files:**
  - `app/booking_app.py`
  - `app/errors.py`
  - `app/storage.py`
- **Tests added/updated:**
  - `tests/test_create_booking.py`
  - `tests/test_cancel_booking.py`
- **Error rules:** `/docs/errors/ERROR_RULES.md`
- **Review checklist:** `/docs/review/Review_Checklist_v1.md`
- **AI use log:** `/docs/ai/AI_Use_Log.md`
- **CI workflow:** `/.github/workflows/ci.yml`
- **Idempotent create evidence:**
  - Covered by `test_create_booking_idempotency` in `tests/test_create_booking.py`
  - And by CI run: `<CI-LINK>` (shows tests green).

## Quality Gates Check

- New/updated unit tests cover changed lines in the booking endpoints.
- Contract/behavior tests confirm stable error shape (`status`, `code`, `hint`, `correlationId`).
- Public error responses follow our team schema; stack traces are not leaked.
- Idempotency for `POST /v1/bookings` works (201 on first call, 200 on replay with same `Idempotency-Key`).
- `Review_Checklist_v1.md` exists and is referenced in PR-S10.
- CI (lint/tests) is green and required for merge.
- AI usage for S10 is documented in `/docs/ai/AI_Use_Log.md`.
