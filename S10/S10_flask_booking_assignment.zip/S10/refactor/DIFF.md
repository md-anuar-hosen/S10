# S10 Refactor – Before / After Summary

## Readability

- **Before:** The booking creation and cancellation logic were conceptually a
  single flow (validation, business logic, persistence, error handling), but
  would easily become tangled as more rules are added.
- **After:** The logic is split into:
  - `create_booking` – orchestrates validation, idempotency, and persistence.
  - `cancel_booking` – handles state transitions for an existing booking.
  - `BookingStore` – encapsulates in-memory persistence.
  - `ApiError` + error handlers – keep error mapping in one place.

## Modularity

- **Before:** Validation rules, idempotency, and storage could have lived inside
  one large function.
- **After:**
  - Domain concepts (booking entity) and error mapping are separated.
  - Store implementation is pluggable (`BookingStore` abstraction).
  - Error handling lives in `app/errors.py`, centralising the response shape.

## Error Handling

- **Before:** Error handling could rely on ad-hoc strings or status codes.
- **After:**
  - All public errors use `ApiError` with fields:
    - `status`
    - `code`
    - `hint`
    - `correlationId`
  - Error responses follow `/docs/errors/ERROR_RULES.md`.
  - Unexpected exceptions return `INTERNAL_ERROR` without leaking stack traces.

## Public Contract

- **Status:** Public contract is explicitly defined rather than changed.
- **Endpoints:**
  - `POST /v1/bookings`
    - 201 on first successful create
    - 200 on replay with same `Idempotency-Key`
    - 400 on validation failures (`BOOKING_INVALID_NAME`, `BOOKING_INVALID_EMAIL`, `BOOKING_INVALID_DATE`)
  - `POST /v1/bookings/<id>/cancel`
    - 200 on successful cancel
    - 404 (`BOOKING_NOT_FOUND`) if booking does not exist
    - 409 (`BOOKING_ALREADY_CANCELLED`) if already cancelled

## Tests Impacted

- **Added:**
  - `test_create_booking_happy_path`
  - `test_create_booking_invalid_email`
  - `test_create_booking_idempotency`
  - `test_cancel_booking_happy_path`
  - `test_cancel_booking_not_found`
  - `test_cancel_booking_already_cancelled`

These tests pin the observable behaviour of S1 (CreateBooking) and S2 (CancelBooking).

## Risks & Edge Cases

- Date handling is simplified in this demo (no timezone parsing). There is a risk
  that real-world date rules (e.g. "not in the past") would behave differently
  once implemented.
- In-memory storage (`BookingStore`) is not durable and not thread-safe; for a
  production system a real database and transaction handling would be required.
- Idempotency currently assumes the same logical payload; payload-diff
  validation on replay is not implemented.

## Peer Review Notes

- **Strong choice:**
  - Using a dedicated `ApiError` and central error handler makes the API error
    model explicit and easy to review.
- **Risk:**
  - If more booking states are added (e.g. `PENDING`, `PAID`), cancellation
    rules must be carefully extended and covered by additional tests.
- **Question:**
  - Should the idempotency store be persisted (e.g. Redis/DB) and have an
    expiration mechanism if this pattern is used in production?
