# S11 – Mini Test Plan & Sample Cases

**Team:** Bahgat, Ahmed · Hosen, Md  
**Repo:** https://github.com/md-anuar-hosen/S10

S11 designs a small but realistic test strategy around two key stories
implemented in this repository:

- **S1 – CreateBooking:** `POST /v1/bookings`
- **S2 – CancelBooking:** `POST /v1/bookings/{id}/cancel`

## Artifacts

- **Mini Test Plan:** `/S11/MiniTestPlan.md`
- **Sample Cases (ECP/BVA):** `/S11/SampleCases.md`
- **Stories:**
  - S1: Create booking with name, email, and date, returning a `bookingId`.
  - S2: Cancel an existing booking, updating its status to `CANCELLED`.
- **Error rules:** `/docs/errors/ERROR_RULES.md`
- **AI use log:** `/docs/ai/AI_Use_Log.md` (see S11 entry)

(Optional) Some of the sample cases are already implemented as:

- `tests/test_create_booking.py`
- `tests/test_cancel_booking.py`
