# Mini Test Plan – S11

## 1. Stories in Scope

- **S1 – CreateBooking**
  - As a user, I want to create a booking by providing my name, email, and
    date so that I receive a `bookingId` and a confirmed status.

- **S2 – CancelBooking**
  - As a user, I want to cancel an existing booking (that has not already been
    cancelled) so that its status changes to `CANCELLED`.

## 2. Scope

**In scope now:**

- Functional tests for S1 and S2 (happy paths and key negative/edge cases).
- Validation rules for inputs (email, presence of name/date).
- Error codes and shapes, consistent with `/docs/errors/ERROR_RULES.md`.
- Idempotency behaviour for `POST /v1/bookings` using `Idempotency-Key`.

**Explicitly out of scope now (deferred to later testing work):**

- Full performance and load testing.
- Security hardening and penetration testing (e.g. OWASP ASVS).
- Property-based tests over large input spaces.
- Cross-timezone date semantics.

Repo & branch policy:

- Repo: https://github.com/md-anuar-hosen/S10
- All changes should be made via PRs.
- CI (lint/tests) must be green before merge.

## 3. Test Levels & Targets

### S1 – CreateBooking

- **Unit:**
  - Validation logic (invalid email, missing name/date).
  - Idempotency behaviour around `Idempotency-Key`.
- **Integration:**
  - `POST /v1/bookings` end-to-end using Flask test client:
    - 201 on first valid request.
    - 200 on idempotent replay with same key.
    - 400 with appropriate error codes on invalid input.
- **System:**
  - Simple scenario: simulate a user creating a booking and then viewing the
    response (covered by integration in this small demo).
- **UAT:**
  - PO/teacher checks that response structure and error messages satisfy
    acceptance criteria.

### S2 – CancelBooking

- **Unit:**
  - State transition from `CONFIRMED` to `CANCELLED`.
  - Rules preventing cancel when already `CANCELLED`.
- **Integration:**
  - `POST /v1/bookings/{id}/cancel`:
    - 200 for existing, not-yet-cancelled booking.
    - 404 for non-existing booking.
    - 409 for an already cancelled booking.
- **System:**
  - Scenario: create booking → cancel booking → verify status.
- **UAT:**
  - PO/teacher validates that cancellation behaviour matches expectations.

## 4. Environments, Repos, CI

- **Local:**
  - Developers run `pytest` locally against the Flask app.
- **CI (PR):**
  - GitHub Actions workflow at `/.github/workflows/ci.yml`:
    - Install dependencies from `requirements.txt`.
    - Run `pytest`.
- **CI (main branch):**
  - Same pipeline, ensuring regressions are caught on each push.

## 5. Entry / Exit Criteria

- **Unit exit:**
  - All tests in `tests/` related to S1/S2 pass.
  - Changed-line coverage for S1/S2 endpoints is reasonably high (informal
    target ≥ 80% for this small demo).

- **Integration exit:**
  - Happy paths for S1 and S2 pass.
  - Main error paths (invalid email, not found, already cancelled) pass.
  - Error payloads match `/docs/errors/ERROR_RULES.md` (fields + codes).

- **System/UAT exit:**
  - Teacher/PO can follow a small script:
    - Create booking → see `CONFIRMED`.
    - Cancel booking → see `CANCELLED`.
    - Attempt to cancel again → get 409 with `BOOKING_ALREADY_CANCELLED`.

## 6. Risks

- **R1 – Date semantics:**
  - Risk: Simplified date handling (no "past vs future" validation) does not
    reflect real business rules.
  - Status: Partially acknowledged; deferred to future enhancements.

- **R2 – In-memory storage:**
  - Risk: In-memory `BookingStore` is not persistent or thread-safe.
  - Status: Acceptable for assignment/demo; real system would require DB.

- **R3 – Error coverage:**
  - Risk: Future changes might introduce new error codes without updating
    `/docs/errors/ERROR_RULES.md`.
  - Status: Mitigated by requiring checklist checks and test updates on PRs.

## 7. To Dedicated Testing Course (Handover)

These items are explicitly deferred and should be addressed in a more
comprehensive testing phase:

1. **Perf-01 (S1):**  
   Load test `POST /v1/bookings` to ensure p95 latency < 200 ms at a target
   RPS (e.g. 200) in a more realistic environment.

2. **Perf-02 (S2):**  
   Endurance tests where many create/cancel operations are performed over
   time; check resource usage and stability.

3. **Sec-01 (Auth & Session):**  
   Introduce authentication and authorisation, and test according to OWASP
   ASVS for login/session management around the booking endpoints.

4. **Prop-01 (Property-based testing):**  
   Use property-based tests (e.g. Hypothesis) for booking input combinations
   (names/emails/dates) to explore more edge cases automatically.

5. **Obs-01 (Observability):**  
   Verify logging and tracing in a real environment (logs, metrics, traces)
   using `correlationId` to trace requests end-to-end.
