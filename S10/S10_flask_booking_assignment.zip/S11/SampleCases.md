# Sample Cases – S11

This file documents ECP/BVA-based sample test cases for:

- **S1 – CreateBooking** (`POST /v1/bookings`)
- **S2 – CancelBooking** (`POST /v1/bookings/{id}/cancel`)

---

## S1 – CreateBooking

### Inputs, Outputs, Rules

- **Inputs:**
  - `name` (string, required, trimmed)
  - `email` (string, must contain `@`)
  - `date` (string, required; in this demo, not fully validated semantically)
- **Outputs:**
  - On success: 201 with `{ id, name, email, date, status }`
  - On replay with same `Idempotency-Key`: 200 with same `id`
  - On validation errors: 400 with appropriate error `code` and `hint`
- **Business rules (simplified):**
  - `name` must not be empty after trimming.
  - `email` must contain `@`.
  - `date` must not be empty.
- **Errors (per ERROR_RULES):**
  - `BOOKING_INVALID_NAME`
  - `BOOKING_INVALID_EMAIL`
  - `BOOKING_INVALID_DATE`

### Equivalence Classes

- `name`
  - `V_name`: non-empty, trimmed string
  - `I_name_empty`: empty or whitespace-only string

- `email`
  - `V_email`: string containing `@`
  - `I_email_invalid`: string without `@`
  - `I_email_empty`: empty string

- `date`
  - `V_date`: non-empty string
  - `I_date_empty`: empty string

- `Idempotency-Key` (header)
  - `V_key_new`: key not seen before
  - `V_key_existing`: key that has been used before
  - `I_key_missing`: no key provided (still valid; request is non-idempotent)

### Boundaries

For this simplified example we don't have numeric ranges, but we do have
interesting "boundaries" in terms of presence/absence:

- `name`: `""` (invalid) vs `"A"` (valid)
- `email`: `"userexample.com"` (invalid) vs `"user@example.com"` (valid)
- `date`: `""` (invalid) vs `"2025-12-01"` (valid)

### Test Cases

#### TC1 [S1][V_name][V_email][V_date][I_key_missing] – Happy Path

- **Pre:** None.
- **Input:**
  - `POST /v1/bookings`
  - Body: `{ "name": "Alice", "email": "alice@example.com", "date": "2025-12-01" }`
- **Expected:**
  - Status: `201`
  - Body:
    - Contains `id`
    - `name == "Alice"`
    - `email == "alice@example.com"`
    - `status == "CONFIRMED"`
    - `correlationId` present.

#### TC2 [S1][I_email_invalid] – Invalid Email

- **Input:**
  - Body: `{ "name": "Alice", "email": "invalid-email", "date": "2025-12-01" }`
- **Expected:**
  - Status: `400`
  - `code == "BOOKING_INVALID_EMAIL"`
  - `hint` explains that valid email is required.
  - `correlationId` present.

#### TC3 [S1][I_name_empty] – Empty Name

- **Input:**
  - Body: `{ "name": "   ", "email": "alice@example.com", "date": "2025-12-01" }`
- **Expected:**
  - Status: `400`
  - `code == "BOOKING_INVALID_NAME"`

#### TC4 [S1][I_date_empty] – Missing Date

- **Input:**
  - Body: `{ "name": "Alice", "email": "alice@example.com", "date": "" }`
- **Expected:**
  - Status: `400`
  - `code == "BOOKING_INVALID_DATE"`

#### TC5 [S1][Idempotent][V_key_new→existing] – Idempotency Key Replay

- **Pre:** None.
- **Input 1:**
  - Headers: `Idempotency-Key: abc-123`
  - Body: `{ "name": "Bob", "email": "bob@example.com", "date": "2025-12-01" }`
- **Expected 1:**
  - Status: `201`
  - Body: contains `id = X`
- **Input 2 (replay):**
  - Same headers and body.
- **Expected 2:**
  - Status: `200`
  - Body: contains same `id = X`
  - Demonstrates idempotent create behaviour.

---

## S2 – CancelBooking

### Inputs, Outputs, Rules

- **Inputs:**
  - `bookingId` (path parameter)
- **Outputs:**
  - On success: 200 with updated booking (`status == "CANCELLED"`)
  - On not found: 404 with `BOOKING_NOT_FOUND`
  - On already cancelled: 409 with `BOOKING_ALREADY_CANCELLED`
- **Business rules:**
  - A booking in status `CONFIRMED` can be cancelled.
  - A booking in status `CANCELLED` cannot be cancelled again.

### Equivalence Classes

- `bookingId`
  - `V_booking_existing_cancellable`: existing booking in `CONFIRMED` state.
  - `V_booking_existing_not_cancellable`: existing booking in `CANCELLED` state.
  - `I_booking_non_existing`: no booking with that ID.

### Test Cases

#### TC6 [S2][V_booking_existing_cancellable] – Happy Cancel

- **Pre:**
  - A booking is created via `POST /v1/bookings` and returns `id = B1`.
- **Input:**
  - `POST /v1/bookings/B1/cancel`
- **Expected:**
  - Status: `200`
  - Body:
    - `id == B1`
    - `status == "CANCELLED"`
    - `correlationId` present.

#### TC7 [S2][I_booking_non_existing] – Cancel Non-existing Booking

- **Pre:** No booking with ID `non-existing-id`.
- **Input:**
  - `POST /v1/bookings/non-existing-id/cancel`
- **Expected:**
  - Status: `404`
  - `code == "BOOKING_NOT_FOUND"`

#### TC8 [S2][V_booking_existing_not_cancellable] – Cancel Already Cancelled

- **Pre:**
  - Create a booking `B2`.
  - Cancel it once (becomes `CANCELLED`).
- **Input:**
  - `POST /v1/bookings/B2/cancel` again.
- **Expected:**
  - Status: `409`
  - `code == "BOOKING_ALREADY_CANCELLED"`
