import pytest
from app.booking_app import create_app


@pytest.fixture
def client():
    app = create_app()
    app.config["TESTING"] = True
    return app.test_client()


def create_sample_booking(client):
    payload = {"name": "Charlie", "email": "charlie@example.com", "date": "2025-12-02"}
    resp = client.post("/v1/bookings", json=payload)
    assert resp.status_code == 201
    return resp.get_json()["id"]


def test_cancel_booking_happy_path(client):
    booking_id = create_sample_booking(client)
    resp = client.post(f"/v1/bookings/{booking_id}/cancel")
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["status"] == "CANCELLED"
    assert data["id"] == booking_id


def test_cancel_booking_not_found(client):
    resp = client.post("/v1/bookings/non-existing-id/cancel")
    assert resp.status_code == 404
    data = resp.get_json()
    assert data["code"] == "BOOKING_NOT_FOUND"


def test_cancel_booking_already_cancelled(client):
    booking_id = create_sample_booking(client)
    resp1 = client.post(f"/v1/bookings/{booking_id}/cancel")
    assert resp1.status_code == 200

    resp2 = client.post(f"/v1/bookings/{booking_id}/cancel")
    assert resp2.status_code == 409
    data = resp2.get_json()
    assert data["code"] == "BOOKING_ALREADY_CANCELLED"
