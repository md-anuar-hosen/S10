import pytest
from app.booking_app import create_app


@pytest.fixture
def client():
    app = create_app()
    app.config["TESTING"] = True
    return app.test_client()


def test_create_booking_happy_path(client):
    payload = {"name": "Alice", "email": "alice@example.com", "date": "2025-12-01"}
    resp = client.post("/v1/bookings", json=payload)
    assert resp.status_code == 201
    data = resp.get_json()
    assert data["name"] == "Alice"
    assert data["email"] == "alice@example.com"
    assert data["status"] == "CONFIRMED"
    assert "id" in data
    assert "correlationId" in data


def test_create_booking_invalid_email(client):
    payload = {"name": "Alice", "email": "invalid-email", "date": "2025-12-01"}
    resp = client.post("/v1/bookings", json=payload)
    assert resp.status_code == 400
    data = resp.get_json()
    assert data["code"] == "BOOKING_INVALID_EMAIL"
    assert "correlationId" in data


def test_create_booking_idempotency(client):
    payload = {"name": "Bob", "email": "bob@example.com", "date": "2025-12-01"}
    headers = {"Idempotency-Key": "abc-123"}
    resp1 = client.post("/v1/bookings", json=payload, headers=headers)
    resp2 = client.post("/v1/bookings", json=payload, headers=headers)

    assert resp1.status_code == 201
    assert resp2.status_code == 200

    data1 = resp1.get_json()
    data2 = resp2.get_json()
    assert data1["id"] == data2["id"]
    assert data1["status"] == data2["status"] == "CONFIRMED"
