import sys
from pathlib import Path

# Add project root to sys.path so 'app' package is importable in tests
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
